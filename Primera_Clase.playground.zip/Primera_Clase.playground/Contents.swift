import UIKit

var variableString = "Hola"
variableString += "¿Cómo estás?"
print(variableString)

for character in "Hola como estas"{
    print(character)
}
    /*
    let caracteresFifas: [Character] =
    ["S", "i", "u", "u", "u", "u", "!"]
    let fifas = String(caracteresFifas)
    print(fifas)
}
     */
