import UIKit

var greeting = "Hello, playground"
/*
let contacto = (5567862374, "Lizeth")
//contacto es de tipo int y string

let (telefono, nombre) = contacto
print("El telefono es \(telefono)")
print("El usuario es \(nombre)")

*/
/*
var temperatura = 20
if temperatura > 25 {
    print("Hace calor ):")
} else if temperatura <= 10 {
    print("Ahora hace frío ):")
} else {
    print("El clima esta bonito (:")
}
*/

let dia = "Martes"

if dia == "Lunes" {
    print("Feliz inicio de semana (:")
} else {
    print("Aún no es Lunes pa ): es \(dia)")
}
